package com.cristian.botondeincendios;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        final Button botonActivador = findViewById(R.id.incendio);

        botonActivador.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                httpHandler handler = new httpHandler();
                String txt = handler.post("http://breeze2-194.collaboratory.avaya.com/services/EventingConnector/events");


            }
        });
    }
}
